$(document).ready(function(){
    
   function triggereveryseconds() {
        //get current time
        var date = new Date();

        var hours = date.getHours();
        var minutes = date.getMinutes();
        var seconds = date.getSeconds();

        var session = "AM";        
            // alert("Hours : " +hours+" "+minutes+" "+seconds);

        if(hours == 0)
        {
          hours = 12;
        }

        if(hours >= 12){
          session = "PM";
        }

        if(hours < 12){
         hours = hours - 12;
        }
        
       hours = hours < 10 ? "0" +hours : hours;

       minutes = minutes < 10 ? "0"+minutes : minutes;

       seconds = seconds <10 ? "0"+seconds :seconds;

        $(".hours").text(hours);
        $(".minutes").text(minutes);
        $(".seconds").text(seconds);
        $(".session").text(session);


        setTimeout(triggereveryseconds,1000);

       }
       triggereveryseconds();

   
});